"Python bindings for the Panda3D libraries"

__version__ = '1.11.0.dev4050'
